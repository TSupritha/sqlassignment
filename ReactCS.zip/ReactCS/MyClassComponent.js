import React, {Component} from "react";
class MyClassComponent extends Component{
    render(){
        return(
            <div>
                <h1>THIS IS MY CLASS COMPONENT</h1>
            </div>
        )
    }
}
export default MyClassComponent