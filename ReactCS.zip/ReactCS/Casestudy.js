import React, {Component} from 'react';
import axios from 'axios';

class Casestudy extends Component{
    constructor(){
        super()
        this.state={
            TASKID:'',
            OWNERID:'',
            CREATORID:'',
            PRIORITY:'',
            ISBOOKMARKED:'',
            NAME:'',
            NOTES:'',
            STATUS:'',
            DESCRIPTION:'',
            CREATED_ON:'',
            STATUS_CHANGED_ON:''

        }
        this.handleClick=this.handleClick.bind(this)
    }

    handleClick(){
        axios.get("http://localhost:8080/task")
        .then(response=>this.setState({TASKID:response.data[0].task_ID, 
                                        OWNERID:response.data[0].owner_ID,
                                        CREATORID:response.data[0].creator_ID,
                                        PRIORITY:response.data[0].priority,
                                        ISBOOKMARKED:response.data[0].isbookmarked,
                                        NAME:response.data[0].name,
                                        NOTES:response.data[0].notes,
                                        STATUS:response.data[0].status,
                                        DESCRIPTION:response.data[0].description,
                                        CREATED_ON:response.data[0].created_ON,
                                         STATUS_CHANGED_ON:response.data[0].status_CHANGED_ON,
                                        
                                         TASKID:response.data[1].task_ID, 
                                         OWNERID:response.data[1].owner_ID,
                                         CREATORID:response.data[1].creator_ID,
                                         PRIORITY:response.data[1].priority,
                                         ISBOOKMARKED:response.data[1].isbookmarked,
                                         NAME:response.data[1].name,
                                         NOTES:response.data[1].notes,
                                         STATUS:response.data[1].status,
                                         DESCRIPTION:response.data[1].description,
                                         CREATED_ON:response.data[1].created_ON,
                                          STATUS_CHANGED_ON:response.data[1].status_CHANGED_ON,
                                        
                                          TASKID:response.data[2].task_ID, 
                                          OWNERID:response.data[2].owner_ID,
                                          CREATORID:response.data[2].creator_ID,
                                          PRIORITY:response.data[2].priority,
                                          ISBOOKMARKED:response.data[2].isbookmarked,
                                          NAME:response.data[2].name,
                                          NOTES:response.data[2].notes,
                                          STATUS:response.data[2].status,
                                          DESCRIPTION:response.data[2].description,
                                          CREATED_ON:response.data[2].created_ON,
                                           STATUS_CHANGED_ON:response.data[2].status_CHANGED_ON,
                                        
                                        
                                           TASKID:response.data[3].task_ID, 
                                           OWNERID:response.data[3].owner_ID,
                                           CREATORID:response.data[3].creator_ID,
                                           PRIORITY:response.data[3].priority,
                                           ISBOOKMARKED:response.data[3].isbookmarked,
                                           NAME:response.data[3].name,
                                           NOTES:response.data[3].notes,
                                           STATUS:response.data[3].status,
                                           DESCRIPTION:response.data[3].description,
                                           CREATED_ON:response.data[3].created_ON,
                                            STATUS_CHANGED_ON:response.data[3].status_CHANGED_ON})
              
            
        )
    }
    

    render(){
        return(
            <div>
                <button className='button' onClick={this.handleClick}>Click Me</button>
                   <p >{this.state.TASKID}</p>
                   <p>{this.state.OWNERID}</p>
                   <p>{this.state.CREATORID}</p>
                   <p>{this.state.PRIORITY}</p>
                 
                   <p>{this.state.CREATORID}</p>
                   <p>{this.state.PRIORITY}</p>
                   <p>{this.state.ISBOOKMARKED}</p>
                   <p>{this.state.NAME}</p>
                   <p>{this.state.NOTES}</p>
                   <p>{this.state.STATUS}</p>
                   <p>{this.state.DESCRIPTION}</p>
                   <p>{this.state.CREATED_ON}</p>
                   <p>{this.state.STATUS_CHANGED_ON}</p>
            </div>
        )
    }
}
export default Casestudy