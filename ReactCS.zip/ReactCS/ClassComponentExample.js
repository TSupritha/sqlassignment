import React,{Component} from "react";
import ClassComponent from "./ClassComponent";
import PropsExample from "./PropsExample";
import StudentClassCom from "./StudentClassCom";
 
class ClassComponentExample extends Component{
    render(){
        return(
            <div>
                <PropsExample name="SUMANA" age={22}>
                   
                    <p>THIS IS M CHILD TAG</p>
                    </PropsExample>
                  
                    <PropsExample name="BHAVANA"/>
                    <ClassComponent name="SOWJANYA" age={22}></ClassComponent>
                    <StudentClassCom id={21043} name="SUMANA" marks={90}></StudentClassCom> 
            </div>
        )
    }
}
export default ClassComponentExample;