import React, {Component} from 'react';
import axios from 'axios';

class AddTask extends Component{
    constructor(props){
        super(props)
        this.state={
            task_ID :'',
            owner_ID :'',
            creator_ID :'',
            name : '',
            description :'',
            status :'',
            priority :'',
            notes :'',
            isbookmarked : '',
            created_ON :'',
            status_CHANGED_ON :''
            
        }
        this.changeHandler=this.changeHandler.bind(this);
        this.submithandler=this.submithandler.bind(this);
    }
    changeHandler(e){
        this.setState({[e.target.name]:e.target.value})
    }
    submithandler(e){
        e.preventDefault()
        console.log(this.state)
        axios
        .post('http://localhost:8080/addtask',this.state)
        .then(response=>{
            console.log(response)
        })
        .catch(error=>{
            console.log(error)
        })
    }
    render(){
        const {task_ID, owner_ID,creator_ID,name, description, status, priority, notes, isbookmarked, created_ON, status_CHANGED_ON}=this.state
        return(
            <div style={{"backgroundColor":"yellow","color":"black"}}>
                <form onSubmit={this.submithandler}>
                    <center>
                    <div>
                        TASK-ID:
                        <input type="number" name ="task_ID" value ={task_ID} onChange={this.changeHandler}/>
                    </div><br/>
                    <div>
                        OWNER-ID:
                        <input type="number" name ="owner_ID" value ={owner_ID} onChange={this.changeHandler}/>
                    </div><br/>
                    <div>
                        CREATOR-ID:
                        <input type="number" name ="creator_ID" value ={creator_ID} onChange={this.changeHandler}/>
                    </div><br/>
                    <div>
                        NAME:
                        <input type="text" name ="name" value ={name} onChange={this.changeHandler}/>
                    </div><br/>
                    <div>
                        DESCRIPTION:
                        <input type="text" name ="description" value ={description} onChange={this.changeHandler}/>
                    </div><br/>
                    <div>
                        STATUS:
                        <select id ="status" name="status" value ={status} onChange={this.changeHandler}>
                            <option value="select">select</option>
                            <option value ="InProgress">InProgress</option>
                            <option value ="OnHold">OnHold</option>
                            <option value ="Cancelled">Cancelled</option>
                        </select>
                    </div><br/>
                    <div>
                       PRIORITY:
                        <select id ="priority" name ="priority" value ={priority} onChange={this.changeHandler}>
                            <option value ="select">select</option>
                            <option value ="medium">medium</option>
                            <option value ="low">low</option>
                            <option value = "high">high</option>
                        </select><br/>
                    </div>
                    <div>
                        NOTES:
                        <input type="text" name ="notes" value ={notes} onChange={this.changeHandler}/>
                    </div>
                    <div>
                       ISBOOKMARKED:
                        <select id ="isbookmarked" name ="isbookmarked" value ={isbookmarked} onChange={this.changeHandler}>
                            <option value ="T/F">T/F</option>
                            <option value ="false">false</option>
                            <option value = "true">true</option>  
                        </select>
                    </div><br/>
                    <div>
                        CREATED-ON:
                        <input type="date" name ="created_ON" value ={created_ON} onChange={this.changeHandler}/>
                    </div><br/>

    
                    <div>
                        STATUS-CHANGED-ON:
                        <input type="date" name ="status_CHANGED_ON" value ={status_CHANGED_ON} onChange={this.changeHandler}/>
                    </div><br/><br/>

                    

                    <button className='button' onClick={this.handleClick}>ADD-TASK</button>
                    
                    </center>
                </form>
            </div>
        )
    }

}
export default AddTask;