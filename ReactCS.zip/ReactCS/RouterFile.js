

import React from "react";

import ReactDom from "react-dom";

import { Route,Link, BrowserRouter as Router, Routes} from "react-router-dom";
import AddTask from "./AddTask";
import GetTaskData from "./GetTaskData";
import UpdatePriority from "./UpdatePriority";
import App from "./App";
import UpdateBookmark from "./UpdateBookmark";
import DeleteTask from "./DeleteTask";
import UpdateNotes from "./UpdateNotes";
import SearchTask from "./SearchTask";
import TrackStatus from "./TrackStatus";
import AssignTask from "./AssignTask";
const routing = (

<Router>
    <center>
       
    <div style={{"backgroundColor":"yellow","color":"black"}}>
      <h1>WELCOME TO TASK TRACKING SYSTEM!!!</h1>
            
           



                

             <Link to="/ALL-TASK">ALL-TASKS</Link><br/><br/>

            

               

             <Link to="/ADD-TASK">ADD-TASK</Link><br/><br/>

                

                

            <Link to="/UPDATE-PRIORITY">UPDATE-PRIORITY</Link><br/><br/>




                
            <Link to="/UPDATE-BOOKMARK">UPDATE-BOOKMARK</Link><br/><br/>



                 
            <Link to="/UPDATE-NOTES">UPDATE-NOTES</Link><br/><br/>



            
            <Link to="/SEARCH-TASK">SEARCH-TASK</Link><br/><br/>



            <Link to="/TRACK-STATUS">TRACK-STATUS</Link><br/><br/>
            
            <Link to="/ASSIGN-TASK">ASSIGN-TASK</Link><br/><br/>
            
            
            <Link to="/DELETE-TASK">DELETE-TASK</Link><br/><br/>
             
           
        </div>
  </center>
              
            <Routes>

               
               
                <Route path="/ALL-TASK" element={<GetTaskData/>}/>

                <Route path="/ADD-TASK" element={<AddTask/>}/>
                <Route path="/UPDATE-PRIORITY" element={<UpdatePriority/>}/>
                <Route path="/UPDATE-BOOKMARK" element={<UpdateBookmark/>}/>
                <Route path="/UPDATE-NOTES" element={<UpdateNotes/>}/>
                <Route path="/SEARCH-TASK" element={<SearchTask/>}/>
                <Route path="/TRACK-STATUS" element={<TrackStatus/>}/>
                <Route path="/ASSIGN-TASK" element={<AssignTask/>}/>
                <Route path="/DELETE-TASK" element={<DeleteTask/>}/>
             
            </Routes>

       
</Router>

)

export default routing;