import logo from './logo.svg';
import './App.css';
import MyCom from './MyCom';
import MyClassComponent from './MyClassComponent';
import StudentClassCom from './StudentClassCom';
import { render } from '@testing-library/react';
import ClassComponentExample from './ClassComponentExample';
import ClassComponent from './ClassComponent';
import StateExample from './StateExample';
import ClassCounter from './ReactHookExample/ClassCounter';
import HookCounter from './ReactHookExample/HookCounter';
import NameList from './NameList';
import RegisterForm from './RegisterForm';
import ColumnComponent from './ColumnComponent';
import Casestudy from './Casestudy';
import store from './Redux/store'
import CakeContainer from './Components/CakeContainer'
import { Provider } from 'react-redux';
import GetReactData from './GetReactData';
import CounterOne from './ReducerHook/CounterOne';
import HookuseEffectCounter from './ReducerHook/useEffectComponents/HookuseEffectCounter';
import useCustomCountHook from './CustomHookCreation/useCustomCountHook';
import GetTaskData from './GetTaskData';
import AddTask from './AddTask';
import UpdatePriority from './UpdatePriority';
import UpdateBookmark from './UpdateBookmark';
import routing from './RouterFile';
export default function App()
 {
   
  return (
    <Provider store={store}>
     <div>
     
     </div>
    </Provider>
    

    

  );
}

 
 
