import React from 'react';

function ColumnComponent(){
    return(
        <>
        <td> NAME</td>
        <td>SUMANA</td>
        </>
    )
}
export default ColumnComponent