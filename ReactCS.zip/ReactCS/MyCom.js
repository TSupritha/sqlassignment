import React from "react";

export default function MyCom(){
    return(
        <div>
            <h1>MY FUNCTION COMPONENT</h1>
        </div>
    );
}