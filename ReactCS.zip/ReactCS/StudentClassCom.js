import React,{Component} from "react";

class StudentClassCom extends Component{
    render(){
        return(
        <div>
            {this.props.id}
            {this.props.name}
            {this.props.marks}
        </div>
        );
    }

}
export default StudentClassCom;