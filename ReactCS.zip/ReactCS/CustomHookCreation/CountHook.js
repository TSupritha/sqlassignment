import React from 'react'
import useCustomCountHook from './useCustomCountHook'


function CountHook(){
    const [count,increment, decrement, reset]=useCustomCountHook(10,10)
    return(
        <div>
          <h1>Count {count}</h1>  
          <button onClick={increment}>INCREMENT</button>
          <button onClick={decrement}>DECREMENT</button>
          <button onClick={reset}>RESET</button>
        </div>
    )
}
export default CountHook;