export interface UpdateNotesInterface{
    task_ID :number;
    
    notes : string;
    
}