export interface UpdateInterface{
    task_ID :number;
    
    priority : string;
    
}