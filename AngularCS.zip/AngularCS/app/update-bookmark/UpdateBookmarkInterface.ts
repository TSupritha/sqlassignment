export interface UpdateBookmarkInterface{
    task_ID :number;
    
    bookmark: boolean;
    
}