export class TaskDetails{
    task_ID!:number;

    creator_ID!:number;

    owner_ID!:number;

    description!:string;

    status!:string;

    priority!:string;

    notes!:string;

    isbookmarked!:boolean;

    created_ON!:string;

    status_CHANGED_ON!:string;

    name!:string;

}