export interface deletetaskinterface{

    task_ID:number;

}