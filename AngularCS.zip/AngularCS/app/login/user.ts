import { EmailValidator } from "@angular/forms";
export class User{
    user_ID:number=1;

    password!:string;

    username!:string;

    email:string="janu@123.gamilcom";

    first_NAME:string="janu";

    last_NAME:string="revella";

    contact_NUMBER:number=64736746473;

    role:string="tester"

    is_ACTIVE:boolean=true;

    dob:string="200-10-12"

    created_ON:string="2000-12-10"

}