export interface UpdateOwneridInterface{
    task_ID :number;
    
    owner_ID : number;
    
}